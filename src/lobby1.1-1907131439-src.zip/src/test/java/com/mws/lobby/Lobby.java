package com.mws.lobby;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class Lobby extends JavaPlugin {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
	    if (cmd.getName().equalsIgnoreCase("lobby") || cmd.getName().equalsIgnoreCase("l")) { // 如果玩家输入了/l则执行如下内容...
	    // 所需要执行的事（此处略）
	    	getLogger().info(ChatColor.AQUA+sender.getName()+"使用了/lobby");
	        return true;
	    } //如果以上内容成功执行，则返回true 
	    // 如果执行失败，则返回false.
	    return false;
	}
	
	@Override
	public void onEnable()
	{
		getLogger().info(ChatColor.AQUA+"LobbyChoose已被加载！");
	}
	
	@Override
	public void onDisable()
	{
		getLogger().info(ChatColor.AQUA+"LobbyChoose已被卸载！");
	}
}
