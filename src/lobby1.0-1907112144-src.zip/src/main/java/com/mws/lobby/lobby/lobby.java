package com.mws.lobby.lobby;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class lobby extends JavaPlugin {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
	    if (cmd.getName().equalsIgnoreCase("lobby") || cmd.getName().equalsIgnoreCase("l")) { // 如果玩家输入了/basic则执行如下内容...
	    // 所需要执行的事（此处略）
	        return true;
	    } //如果以上内容成功执行，则返回true 
	    // 如果执行失败，则返回false.
	    return false;
	}
}
